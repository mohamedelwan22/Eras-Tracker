// OpenAlex API Service
// TODO: Phase 2 - External API Integration

export async function searchOpenAlex(year: number, field: string) {
    // TODO: Implement OpenAlex API integration
    throw new Error('Not implemented - Phase 2');
}
